
#include"motor.h"

void Motor_Init(void)
  {
	AIN1(0),AIN2(0);
	BIN1(0),BIN2(0);
  }

void Set_Pwm(int moto1,int moto2)
{
	if(moto1<0)		  AIN2(1),			AIN1(0);
	else 	          AIN2(0),			AIN1(1);
	PWMA(myabs(moto1));
	if(moto2<0)    	  BIN1(1),			BIN2(0);
	else              BIN1(0),			BIN2(1);
	PWMB(myabs(moto2));	
}



int myabs(int a)
{ 		   
	  int temp;
		if(a<0)  temp=-a;  
	  else temp=a;
	  return temp;
}

/*
void Xianfu_Pwm(void)
{
    if(Moto1<-2400 ) Moto1=-2400 ;
		if(Moto1>2400 )  Moto1=2400 ;
	  if(Moto2<-2400 ) Moto2=-2400 ;
		if(Moto2>2400 )  Moto2=2400 ;
}
*/



//void Turn_Off(float angle)
//{
//		if(angle<-40||angle>40)	
//		{	                                  
//				Moto1(0);
//				Moto2(0);
//		}
//}
	
