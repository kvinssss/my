#include "control.h"
#include "move.h"
#include "sys.h"
#include "ti/driverlib/dl_uart.h"



float Kp_sensor = 6.134, Ki_sensor = 0.013, Kd_sensor = 2.76;//pidÍäµÀ²ÎÊý²ÎÊý
volatile float sensor_bias = 0;
volatile float sensor_bias_last = 0;
volatile float P = 0, I = 0, D = 0, PID_value = 0;  //pidÖ±µÀ²ÎÊý
volatile int   PWM_value_R,  PWM_value_L;
uint8_t stop=0;
int L1,L2,M0,R1,R2;
void xunji();



void sensor_Init()
{
    
}


void sensor_read()
{

/*
   switch(L1+L2+M0+R1+R2)
    {
    case 1:
        if(M0==1)        sensor_bias = 0;
        else if(L1==1)   sensor_bias = 50;
        else if(R1==1)   sensor_bias = -50;
        else if(L2==1)   sensor_bias = 75;
        else if(R2==1)   sensor_bias = -75;
    case 2:

    case 3:
    case 4:
    case 5:
    }
    */
     xunji();

    if((L1 == 0)&&(M0 == 1)&&(R1 == 0))// 0 1 0
    {
        sensor_bias = 0;
    }
    if((L1 == 1)&&(M0 == 1)&&(R1 == 0))// 1 1 0
    {
        sensor_bias = -40.5;
    }
    if((L1 == 0)&&(M0 == 1)&&(R1 == 1))// 0 1 1
    {
        sensor_bias = 40.5;
    }
    if((L1 == 1)&&(M0 == 0)&&(R1 == 0))// 1 0 0
    {
        sensor_bias = -55.5;
    }
    if((L1 == 0)&&(M0 == 0)&&(R1 == 1))// 0 0 1
    {
        sensor_bias = 55.5;
    }
    if(L2==1)
    {
        sensor_bias = -65.5;
    }
    if(R2==1)
    {
        sensor_bias = 65.5;
    }
    if((L2 == 0)&&(L1 == 0)&&(M0 == 0)&&(R1 == 0)&&(R2 == 0))// 0 0 0 0 0
    {

    }
    if((L2 == 1)&&(L1 == 1)&&(M0 == 1)&&(R1 == 1)&&(R2 == 1))// 1 1 1 1 1
    {
        stop = 1;
    }
     
}

void Sensor_pid()
{
       sensor_read();
       if(state)
       {
        P = sensor_bias;
        I = I + sensor_bias;
        D = sensor_bias-sensor_bias_last;
        PID_value = Kp_sensor*P + Ki_sensor*I + Kd_sensor*D;
        sensor_bias_last = sensor_bias;


        if(I >=775)I = 775;
        if(I <= -775)I = -775;
        PWM_value_R = 525 - (int)PID_value*0.6;
        PWM_value_L = 525 + (int)PID_value*0.6;
        
        Set_Pwm(PWM_value_R,PWM_value_L);
        if(stop==1)Set_Pwm(0,0);
        stop=0;
       }
      
}

void xunji()
{           
                //五路循迹，识别到高电平
                //第一个传感器      最左边
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_L2_PIN)==GPIO_Sensor_PIN_L2_PIN )            //黑，不亮     高
               {
                L2=1;
               }
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_L2_PIN)!=GPIO_Sensor_PIN_L2_PIN)             //白  亮      低
               {
                L2=0;
               }



                //第二个传感器      
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_L1_PIN)==GPIO_Sensor_PIN_L1_PIN )            //黑，不亮     高
               {
                L1=1;
               }
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_L1_PIN)!=GPIO_Sensor_PIN_L1_PIN)             //白  亮      低
               {
                L1=0;
               }


                 //第三个传感器     
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_M0_PIN)==GPIO_Sensor_PIN_M0_PIN )            //黑，不亮     高
               {
                M0=1;
               }
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_M0_PIN)!=GPIO_Sensor_PIN_M0_PIN)             //白  亮      低
               {
                M0=0;
               }


         //第四个传感器         
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_R1_PIN)==GPIO_Sensor_PIN_R1_PIN )            //黑，不亮     高
               {
                R1=1;
               }
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_R1_PIN)!=GPIO_Sensor_PIN_R1_PIN)             //白  亮      低
               {
                R1=0;
               }





        //第五个传感器         
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_R2_PIN)==GPIO_Sensor_PIN_R2_PIN )            //黑，不亮     高
               {
                R2=1;
               }
              if( DL_GPIO_readPins(GPIO_Sensor_PORT ,GPIO_Sensor_PIN_R2_PIN)!=GPIO_Sensor_PIN_R2_PIN)             //白  亮      低
               {
                R2=0;
               }

}
