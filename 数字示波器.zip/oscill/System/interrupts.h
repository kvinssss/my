#ifndef _INTERRUPT_H
#define _INTERRUPT_H

void interrupt_init(void);
void EXTI0_IRQHandler(void);
void EXTI1_IRQHandler(void);
int16_t getcount(void);

#endif