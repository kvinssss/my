#ifndef __SERVO_H
#define __SERVO_H

void Servo_Init(void);
void X_SetAngle(float Angle);
void Y_SetAngle(float Angle);
#endif
