#include "stm32f10x.h"                  // Device header
#include "PWM.h"

void Servo_Init(void)
{
	PWM_Init();
}

void X_SetAngle(float Angle)
{
	PWM_SetCompare1(Angle / 270 * 2000 + 500);
}

void Y_SetAngle(float Angle)
{
	PWM_SetCompare2(Angle / 270 * 2000 + 500);
}
