#include "interrupt.h"

volatile int EncoderCountL=0,EncoderCountR=0;
volatile int  CountL=0,CountR=0;
void interrupt_Init(void)
{
    NVIC_EnableIRQ(interruptB_INT_IRQN);
}

 
void GROUP1_IRQHandler(void)
{
    uint32_t gpioB;
    gpioB = DL_GPIO_getEnabledInterruptStatus(interruptB_PORT,interruptB_PIN_0_PIN | interruptB_PIN_16_PIN | interruptB_PIN_1_PIN | interruptB_PIN_12_PIN);
 
    if((gpioB & interruptB_PIN_0_PIN) == interruptB_PIN_0_PIN)
    {
        //Pin0上升沿
        if(DL_GPIO_readPins(interruptB_PORT,interruptB_PIN_16_PIN))//P16为高电平
        {
            EncoderCountL--;
            CountL--;
        }
        else//P16为低电平
        {
            EncoderCountL++;
            CountL++;
        }
    }
    
    if((gpioB & interruptB_PIN_16_PIN) == interruptB_PIN_16_PIN)
    {
        //Pin16上升沿
        if(DL_GPIO_readPins(interruptB_PORT,interruptB_PIN_0_PIN))//P0为高电平
        {
            EncoderCountL++;
            CountL++;
        }
        else//P0为低电平
        {
            EncoderCountL--;
            CountL--;
        }
    }

      if((gpioB & interruptB_PIN_1_PIN) == interruptB_PIN_1_PIN)
    {
        //Pin1上升沿
        if(DL_GPIO_readPins(interruptB_PORT,interruptB_PIN_12_PIN))//P12为高电平
        {
            EncoderCountR--;
            CountR--;
        }
        else//P12为低电平
        {
            EncoderCountR++;
            CountR++;
        }
    }
    
    if((gpioB & interruptB_PIN_12_PIN) == interruptB_PIN_12_PIN)
    {
        //Pin12上升沿
        if(DL_GPIO_readPins(interruptB_PORT,interruptB_PIN_1_PIN))//P1为高电平
        {
            EncoderCountR++;
            CountR++;
        }
        else//P1为低电平
        {
            EncoderCountR--;
            CountR--;
        }
    }
    DL_GPIO_clearInterruptStatus(interruptB_PORT, interruptB_PIN_0_PIN | interruptB_PIN_16_PIN | interruptB_PIN_1_PIN | interruptB_PIN_12_PIN);

}
