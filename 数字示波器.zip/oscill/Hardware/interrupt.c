#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "main.h"
int16_t value=1;
int Line_Set[4]={0};
extern int16_t measure_t_ready;
void interrupt_init(void)
{
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA,ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_AFIO,ENABLE);
  GPIO_InitTypeDef GPIO_InitStructure;
  GPIO_InitStructure.GPIO_Mode=GPIO_Mode_IPU;
  GPIO_InitStructure.GPIO_Pin=GPIO_Pin_8|GPIO_Pin_9;
  GPIO_InitStructure.GPIO_Speed=GPIO_Speed_50MHz;
  GPIO_Init(GPIOB,&GPIO_InitStructure);
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource8);  
  GPIO_EXTILineConfig(GPIO_PortSourceGPIOA,GPIO_PinSource9);  
  
  EXTI_InitTypeDef EXTI_InitStructre;
  EXTI_InitStructre.EXTI_Line=EXTI_Line8|EXTI_Line9;
  EXTI_InitStructre.EXTI_LineCmd=ENABLE;
  EXTI_InitStructre.EXTI_Mode=EXTI_Mode_Interrupt;
  EXTI_InitStructre.EXTI_Trigger=EXTI_Trigger_Falling;
  EXTI_Init(&EXTI_InitStructre);
  
  NVIC_PriorityGroupConfig(NVIC_PriorityGroup_2);
  NVIC_InitTypeDef NVIC_InitStructure;
  NVIC_InitStructure.NVIC_IRQChannel=EXTI9_5_IRQn;
  NVIC_InitStructure.NVIC_IRQChannelCmd=ENABLE;
  NVIC_InitStructure.NVIC_IRQChannelPreemptionPriority=2;
  NVIC_InitStructure.NVIC_IRQChannelSubPriority=2;
  NVIC_Init(&NVIC_InitStructure);
  

}

void EXTI9_5_IRQHandler(void)
{
  
 if(EXTI_GetITStatus(EXTI_Line8)==SET)
 {
  delay_us(100);
   if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)==0)
  {
   if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)==0)
   {
     switch(measure_t_ready)
     {
       case 1: {Line_Set[0]++;
        if(Line_Set[0]>=64)
      {
       Line_Set[0]=63; 
      }  
         break; 
       }
       case 2: {Line_Set[1]++;
          if(Line_Set[1]>=64)
      {
       Line_Set[1]=63; 
      }    
          break;      
       }
       case 3: {Line_Set[2]++;
          if(Line_Set[2]>=63)
      {
       Line_Set[2]=63; 
      }  
          break;         
       }
       default :
       {
      if(value<=300)
      value=value+20;
      if(value>300)
      value=value+100; 
	    if(value>17000)
      {
       value=17001; 
        }  
       }  
      }
   }   
  }
   EXTI_ClearITPendingBit(EXTI_Line8);
 }
 
 if(EXTI_GetITStatus(EXTI_Line9)==SET)
 {
   delay_us(100);
    if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_9)==0)
    {  
      if(GPIO_ReadInputDataBit(GPIOA,GPIO_Pin_8)==0)
   {
   switch(measure_t_ready)
     {
       case 1: {Line_Set[0]--;
       if(Line_Set[0]<=0)
      {
       Line_Set[0]=0; 
      }
      break;
       }
       case 2: {Line_Set[1]--;
       if(Line_Set[1]<=0)
      {
       Line_Set[1]=0; 
      } 
      break;
       }
       case 3: {Line_Set[2]--;
       if(Line_Set[2]<=0)
      {
       Line_Set[2]=0; 
      } 
      break;
       }
       
       default :
         {
      if(value<=300)
      value=value-20;
      if(value>300)
      value=value-100;        
	    if(value<50)
      {
       value=1; 
     }     
    }
   }
 }
   }
  EXTI_ClearITPendingBit(EXTI_Line9);
 }
 
 
}

 

 int16_t getvalue(void)
 {
 return value;
 }
 
 int GetLine_Set(void)
 {
 switch(measure_t_ready)
 {
	case 1:return Line_Set[0];break;
	case 2:return Line_Set[1];break;
  case 3:return Line_Set[2];break;
 }
}