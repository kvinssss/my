#include "pwm.h"

void PWM_Init (void)
{
 DL_TimerG_startCounter(PWM_INST);
}

void PWM_SET(uint32_t per)
{
  DL_TimerG_setLoadValue(PWM_INST,per);
}