#include "stm32f10x.h"                  // Device header
#include "Delay.h"
#include "OLED.h"
#include "Servo.h"
#include "Key.h"
#include "PID.h"
#include "usart.h"
#include "Timer.h"
uint8_t KeyNum;
float Angle;

int main(void)
{
	Uart3_Init();
	PID_Init();
	Servo_Init();
	X_SetAngle(135);
  Y_SetAngle(90);
	Timer_Init();//��ʱ����ִ�г���
	OLED_Init();
	
	 //OLED_ShowString(1, 1, "Angle:");\

	while (1)
	{
   OLED_ShowNum(1, 1, GET_X(),3);
   OLED_ShowNum(2, 1, GET_Y(),3);
	}
}
