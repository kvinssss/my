#ifndef __OLED_H
#define __OLED_H

void OLED_Init(void);
void OLED_Clear(void);
void OLED_WriteCommand(uint8_t Command);
void OLED_WriteData(uint8_t Data);
void OLED_ShowChar(uint8_t Line, uint8_t Column, char Char);
void OLED_ShowString(uint8_t Line, uint8_t Column, char *String);
void OLED_ShowNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowSignedNum(uint8_t Line, uint8_t Column, int32_t Number, uint8_t Length);
void OLED_ShowHexNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_ShowBinNum(uint8_t Line, uint8_t Column, uint32_t Number, uint8_t Length);
void OLED_DrawWave(uint8_t x,uint8_t y);
void OLED_SetPos2(unsigned char x, unsigned char y);
void Current_State_Update(uint8_t y);
void Before_State_Update(uint8_t y);
void OLED_ShowCn(uint8_t Line, uint8_t Column, char Char);
void OLED_Init2(void);
void OLED_ShowGif(void);
void OLED_DrawLine(uint8_t x,uint8_t y);
#endif
