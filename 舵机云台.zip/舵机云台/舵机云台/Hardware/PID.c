
#include "pid.h"
PID pid;
 
void PID_Init()
{
	pid.X_Kp = 0.02;
	pid.X_Ki = 0;
	pid.X_Kd = 0;
	pid.X_err = 0;
	pid.X_err_sum = 0;
	pid.X_err_last = 0;
	
	pid.Y_Kp=0.02;
	pid.Y_Ki=0;
	pid.Y_Kd=0;
	pid.Y_err=0.00;
	pid.Y_err_sum=0;
	pid.Y_err_last=0;
}
 
//ˮƽ����
int PID_Level(int x)
{
	int out;
	
	pid.X_err = x-160 ;
	pid.X_err_sum += pid.X_err;
	out = pid.X_Kp*(pid.X_err)+ pid.X_Ki*(pid.X_err_sum)+ pid.X_Kd*(pid.X_err - pid.X_err_last);
	pid.X_err_last = pid.X_err;
	
	return out;
}
 
//��ֱ����
int PID_vertical(int y)
{
	int out;
		
	pid.Y_err = y-120 ;
	pid.Y_err_sum += pid.Y_err;
	out = pid.Y_Kp*(pid.Y_err)+ pid.Y_Ki*(pid.Y_err_sum)+ pid.Y_Kd*(pid.Y_err - pid.Y_err_last);
	pid.Y_err_last = pid.Y_err;
	
	return out;
}
