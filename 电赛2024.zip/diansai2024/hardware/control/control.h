#ifndef __CONTROL_H
#define __CONTROL_H
#include "sys.h"

void Sensor_pid(void);
#endif
