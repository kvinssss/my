#ifndef __KEY_H
#define __KEY_H

void Key_Init(void);
uint8_t Key_GetNum(void);
uint8_t Key_GetNum2(void);
uint8_t Key_Getlight(void);
#endif
