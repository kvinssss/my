#include "stm32f10x.h" // Device header
#include "stdlib.h"
#include "Delay.h"
#include "OLED.h"
#include "AD.h"
#include "interrupt.h"
#include "Key.h"
#include "Timer.h"
void Show_Wave(void);
void Measure_T(void);
void Measure_V(void);
void light_set(void);
void showfhz(void);
uint16_t ADValue,light,light_re;
float Voltage;
int16_t x,value1,f_hz[3]={0},show_fhz=0,T_value;
int measure_t_ready=0,line_set[3],line_set_re[3],value_line[64];
int main(void)
{
	OLED_Init();
  AD_Init();
  Key_Init();
	interrupt_init();
  Timer_init();
  OLED_WriteCommand(0x81);
  OLED_WriteCommand(0xff);
  OLED_ShowCn(2,5,3);
  OLED_ShowChar(2,14,'%');
  OLED_ShowString(1,9,"f:");
  OLED_ShowString(3,9,"T:");
  OLED_ShowString(4,9,"V:");
  OLED_ShowString(1,15,"hz");
  OLED_DrawLine(64,0);
  OLED_DrawLine(64,63);
	while (1)
  {
	Show_Wave();
  Measure_V();
  Measure_T();
  light_set();
  showfhz();
  }
}

void Show_Wave(void)
{
	for(x=0;x<64;x=(x+1))
		{
    value1=getvalue();
		ADValue = AD_GetValue();
		Voltage = (float)ADValue / 4095 * 3.3;
			float count=ADValue*0.015380;	
      Delay_us(value1);
      value_line[x]=count;
      OLED_DrawWave(x,count);
      f_hz[0]++;
  }
}

void showfhz(void)
{
  if(show_fhz==1)
 {  
  OLED_ShowNum(1,11,f_hz[1],4);
  f_hz[2]=f_hz[1];
  show_fhz=0;
  }
}

void Show_Line(void)
{
	for(x=0;x<64;x=(x+1))
		{
      OLED_DrawWave(x, value_line[x]);
  }
}
void Show_Line1(void)
{
	for(x=0;x<64;x=(x+1))
		{
      OLED_DrawLine(x, value_line[x]);
  }
}

void Measure_T(void)
{
 
  if(Key_GetNum()==1)
  {
   measure_t_ready=1;
  while(1)
    {
  line_set_re[0]=line_set[0];
  line_set[0]=GetLine_Set();
   if(line_set_re[0]!=line_set[0]) 
   {     
   Show_Line();
   OLED_DrawLine(63-line_set[0],0);
   OLED_DrawLine(63-line_set[0],63);
   }
      if(Key_GetNum()==1)
      { 
      measure_t_ready=2;
      while(1)
       {
        line_set_re[1]=line_set[1];
        line_set[1]=GetLine_Set();
        if(line_set_re[1]!=line_set[1]) 
        {     
          Show_Line();
          OLED_DrawLine(63-line_set[0],0);
          OLED_DrawLine(63-line_set[0],63);
          OLED_DrawLine(63-line_set[1],0);
          OLED_DrawLine(63-line_set[1],63);
          
          if((line_set[1]-line_set[0])<0)
          {           
          T_value=1000*1000*(line_set[0]-line_set[1])/f_hz[2];
          if(T_value>=10000)            
          {            
            OLED_ShowNum(3,11,T_value/1000,4);
            OLED_ShowString(3,15,"ms");
          }
          else if(T_value<10000)
          {
            OLED_ShowNum(3,11,T_value,4);
            OLED_ShowString(3,15,"us");
          }
              }
          if((line_set[1]-line_set[0])>=0)
          {
           T_value=1000*1000*(line_set[1]-line_set[0])/f_hz[2];
          if(T_value>=10000)            
          {            
            OLED_ShowNum(3,11,T_value/1000,4);
            OLED_ShowString(3,15,"ms");
          }
          else if(T_value<10000)
          {
            OLED_ShowNum(3,11,T_value,4);
            OLED_ShowString(3,15,"us");
          }
            }    
        }
        if(Key_GetNum()==1)
           {
             measure_t_ready=0;
             break;
           }          
       }
       break;
      }
    }
  }
}

void Measure_V(void)
{
   if(Key_GetNum2()==1)
  {
   measure_t_ready=3;
  while(1)
    {
  line_set_re[2]=line_set[2];
  line_set[2]=GetLine_Set();
   if(line_set_re[2]!=line_set[2]) 
   {     
     Show_Line();
     for(x=0;x<64;x++)
     {          
       OLED_DrawLine(x,line_set[2]);
       }
         Show_Line1();
       for(x=0;x<64;x++)
     {  
       if(((63-value_line[x])/8)==((63-line_set[2])/8))
       {
       OLED_SetPos2((63-value_line[x])/8,x);
       OLED_WriteData((0x01<<(63-value_line[x])%8)|(0x01<<(63-line_set[2])%8));
       }
     }

   }
   OLED_ShowNum(4,11,line_set[2]*660/6300,1);
   OLED_ShowChar(4,12,'.');
   OLED_ShowNum(4,13,(line_set[2]*660/63)%100,2);
      if(Key_GetNum2()==1)
      {       
      measure_t_ready=0;
      break;
      }   
    }
 }
  }

void light_set(void)  
{ 
  light_re=light;
  light=Key_Getlight();
  if(light_re!=light)
  {
  OLED_WriteCommand(0x81);
  OLED_WriteCommand(0xff*light/10);
  OLED_ShowNum(2,11,light*10,3);
  }
}

void TIM2_IRQHandler(void)
{
  if(TIM_GetITStatus(TIM2,TIM_IT_Update)==SET)
  { 
    if(abs(f_hz[0]-f_hz[1])>1)
    show_fhz=1; 
    f_hz[1]=f_hz[0];
    f_hz[0]=0;
     
   TIM_ClearITPendingBit(TIM2,TIM_IT_Update);    
  }
    
}