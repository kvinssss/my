#ifndef __INTERRUPT_H
#define __INTERRUPT_H

#include "sys.h"
void interrupt_Init(void);

#endif
