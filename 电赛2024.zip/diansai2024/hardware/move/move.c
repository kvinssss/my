#include "sys.h"
#include "move.h"
volatile float Pitch,Roll,Yaw;
volatile float Yaw_last,Yaw1;
//float Target_Left = 85.000;

void turn_right(float Target_right)
{
    mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
    Yaw_last=Yaw;
    while(Yaw_last==Yaw)
    {
    mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
    }
     Yaw_last=Yaw;
    Yaw1=0;
	while(Yaw1 < Target_right)
	{	

	        Set_Pwm(-600,600);
		    mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
			Yaw1=fabsf(Yaw_last-Yaw);
			if(Yaw1>180) Yaw1=fabsf(Yaw1-360);
	}
	     Set_Pwm(0,0);
}

void turn_left(float Target_left)
{
    mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
   Yaw_last=Yaw;
       while(Yaw_last==Yaw)
    {
    mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
    }
    Yaw_last=Yaw;
    Yaw1=0;
    while(Yaw1 < Target_left)
    {
            Set_Pwm(600,-600);
            mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
            Yaw1=fabsf(Yaw_last-Yaw);
            if(Yaw1>180) Yaw1=fabsf(Yaw1-360);
    }

        Set_Pwm(0,0);
}
