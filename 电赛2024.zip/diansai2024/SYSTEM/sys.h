#ifndef __SYS_H
#define __SYS_H

#include "sys.h"
#include "ti/driverlib/dl_gpio.h"
#include "ti_msp_dl_config.h"
#include "motor.h"
#include "move.h"
#include "pwm.h"
#include "interrupt.h"
#include "tim.h"
#include "oled.h"
#include "control.h"
#include "bsp_mpu6050.h"
#include "inv_mpu.h"
#include "stdio.h"
#include "string.h"
#include <stdint.h>
#define fmq(x)  x?DL_GPIO_setPins(GPIO_fmq_PORT , GPIO_fmq_PIN_13_PIN):DL_GPIO_clearPins(GPIO_fmq_PORT , GPIO_fmq_PIN_13_PIN)
void IIC_init(void);
void delay_us(unsigned long __us);
void delay_ms(unsigned long ms);
void delay_1us(unsigned long __us);
void delay_1ms(unsigned long ms);

//extern int   Moto1,Moto2;
extern volatile float Pitch,Roll,Yaw;
extern volatile int Openmv_X1,Openmv_Y1,Openmv_X2,Openmv_Y2,Openmv_Area1,Openmv_Area2,flag;
extern volatile int Openmv_X3,Openmv_Y3,Openmv_X4,Openmv_Y4,Openmv_Area3,Openmv_Area4;
extern volatile int Openmv_X5,Openmv_Y5,Openmv_X6,Openmv_Y6,Openmv_Area5,Openmv_Area6;
extern volatile uint8_t hc_data;
extern volatile float adc_value[2];
extern volatile int EncoderCountL,EncoderCountR;
extern volatile int SpeedL,SpeedR;
extern int L1,L2,M0,R1,R2;
extern uint8_t state,state_last;
extern int mode;
extern volatile int CountR,CountL;
extern uint8_t flag_m;
#endif
