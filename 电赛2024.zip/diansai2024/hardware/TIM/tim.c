
#include "sys.h"
volatile int SpeedL,SpeedR;
void Timer_Init(void)
{
    NVIC_EnableIRQ(TIMER_0_INST_INT_IRQN);      //使能中断
    DL_TimerG_startCounter(TIMER_0_INST);       //开启计数
    NVIC_EnableIRQ(TIMER_1_INST_INT_IRQN);      //使能中断
    DL_TimerG_startCounter(TIMER_1_INST);       //开启计数
        NVIC_EnableIRQ(TIMER_2_INST_INT_IRQN);      //使能中断
    DL_TimerG_startCounter(TIMER_2_INST);       //开启计数

}


//定时器中断服务函数
void TIMER_0_INST_IRQHandler(void)
{
    switch (DL_TimerG_getPendingInterrupt(TIMER_0_INST)) {
        //关注Zero Event事件

        case DL_TIMER_IIDX_ZERO:
      // mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
        SpeedL=EncoderCountL;
        SpeedR=EncoderCountR;
        EncoderCountL=0;
        EncoderCountR=0;
        DL_TimerG_startCounter(TIMER_0_INST);    
            break;
        default:
            break;
    }
}

void TIMER_1_INST_IRQHandler(void)
{
    switch (DL_TimerG_getPendingInterrupt(TIMER_1_INST)) {
        //关注Zero Event事件
        case DL_TIMER_IIDX_ZERO:

       
            Sensor_pid();
         
         DL_TimerG_startCounter(TIMER_1_INST);       //开启计数
            break;
        default:
            break;
    }
}
//定时器中断服务函数
void TIMER_2_INST_IRQHandler(void)
{
    switch (DL_TimerG_getPendingInterrupt(TIMER_2_INST)) {
        //关注Zero Event事件

        case DL_TIMER_IIDX_ZERO:
        mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
              DL_TimerG_startCounter(TIMER_2_INST);    
            break;
        default:
            break;
    }
}
