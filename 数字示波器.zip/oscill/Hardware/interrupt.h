#ifndef _INTERRUPT_H
#define _INTERRUPT_H

void interrupt_init(void);
void EXTI0_IRQHandler(void);
void EXTI1_IRQHandler(void);
int16_t getvalue(void);
int16_t GetLine_Set(void);
#endif