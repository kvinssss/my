#ifndef __PWM_H
#define __PWM_H
#include"sys.h"
void PWM_Init (void);
void PWM_SET(uint32_t per);
#endif
