/*
 * Copyright (c) 2021, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

#include "motor.h"
#include "sys.h"


float x,y,z;
volatile int counter,tim_counter;
unsigned int disdance;
int mode=0;
uint8_t state,state_last;
uint8_t flag_m=1;
uint8_t goround;
//PID控制直行             第一题的PID
int Position_PID1 (int yaw,int Target)
{ 	
	 float Position_KP=6,Position_KI=0.03,Position_KD=0.6;
	 static float Bias,Pwm,Integral_bias,Last_Bias;
	 Bias=Target-Yaw;                                  //计算偏差
     if(Bias>=180)  Bias=Bias-360;

     if(Bias<=-180) Bias=Bias+360;
	 Integral_bias+=Bias;	                                 //求出偏差的积分
     if(Integral_bias>2000) Integral_bias=2000;
     if(Integral_bias<-2000) Integral_bias=-2000;
	 Pwm=Position_KP*Bias+Position_KI*Integral_bias+Position_KD*(Bias-Last_Bias);       //位置式PID控制器
     if(Pwm>600)  Pwm=600;
     if(Pwm<-600) Pwm=-600;
	 Last_Bias=Bias;                                       //保存上一次偏差 
	 return Pwm;                                           //增量输出
}

void get_key(void)
{
     if( DL_GPIO_readPins(GPIO_KEY_PIN_KEY1_PORT ,GPIO_KEY_PIN_KEY1_PIN)==0)           
    {

      mode=1;
     }
     if( DL_GPIO_readPins(GPIO_KEY_PIN_KEY2_PORT ,GPIO_KEY_PIN_KEY2_PIN)==0)           
    {

      mode=2;
     }
     if( DL_GPIO_readPins(GPIO_KEY_PIN_KEY3_PORT ,GPIO_KEY_PIN_KEY3_PIN)==0)           
    {

      mode=3;
     }
     if( DL_GPIO_readPins(GPIO_KEY_PIN_KEY4_PORT ,GPIO_KEY_PIN_KEY4_PIN)==0)           
    {

      mode=4;
     }

}

void mode1(void)//第一题
{
        if(flag_m==1)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if(!state)  Set_Pwm(550+Position_PID1 (Yaw,0), 500-Position_PID1 (Yaw,0));
        else     
         {
            for(int j=0;j<150;j++) delay_1ms(1);
             state=0;
             Set_Pwm(0, 0);
             for(int i=0;i<50000;i++) fmq(1);
            fmq(0);
            flag_m=0;
            mode=0;
         }
        }
  
}


void mode2(void)//第二题
{
        if(flag_m==1)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if(!state)  Set_Pwm(550+Position_PID1 (Yaw,0), 500-Position_PID1 (Yaw,0));
        else     
         {
            flag_m=2;
             for(int j=0;j<150;j++) delay_1ms(1);
             for(int i=0;i<50000;i++) fmq(1);
            fmq(0);
            state=1;
         }
        }
        
        if(flag_m==2)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if((!state)&&((Yaw<=-155)||(Yaw>=130))) 
       {
        for(int j=0;j<150;j++) delay_1ms(1);
        for(int i=0;i<50000;i++) fmq(1);
        fmq(0);
        flag_m=3;
       }
        }

        if (flag_m==3)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if(!state)  Set_Pwm(550+Position_PID1 (Yaw,-175), 500-Position_PID1 (Yaw,-175));
        else     
         {
            flag_m=4;
            for(int j=0;j<150;j++) delay_1ms(1);
             for(int i=0;i<50000;i++) fmq(1);
            fmq(0);
            state=1;
         }
        }

        if(flag_m==4)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if((!state)&&(Yaw<30)&&(Yaw>-30)) 
       {
       for(int j=0;j<150;j++) delay_1ms(1);
        Set_Pwm(0, 0);
        for(int i=0;i<50000;i++) fmq(1);
        fmq(0);
        flag_m=0;
        mode=0;
        state=0;
       }

        }
        

}

void mode3(void)//第三题
{
        if(flag_m==1)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if(!state)  Set_Pwm(600+Position_PID1 (Yaw,-36), 540-Position_PID1 (Yaw,-36));
        else     
         {
            flag_m=2;
             for(int j=0;j<150;j++) delay_1ms(1);
             for(int i=0;i<50000;i++) fmq(1);
            fmq(0);
            state=1;
         }
        }
        
        if(flag_m==2)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if((!state)&&((Yaw<=-150)||(Yaw>=150))) 
       {
        for(int j=0;j<150;j++) delay_1ms(1);
        for(int i=0;i<50000;i++) fmq(1);
        fmq(0);
        flag_m=3;
       }
        }

        if (flag_m==3)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if(!state)  Set_Pwm(600+Position_PID1 (Yaw,-143), 540-Position_PID1 (Yaw,-143));
        else     
         {
            flag_m=4;
              for(int j=0;j<150;j++) delay_1ms(1);
            for(int i=0;i<50000;i++) fmq(1);
            fmq(0);
            state=1;
         }
        }

        if(flag_m==4)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if((!state)&&(Yaw<30)&&(Yaw>-30)) 
       {
        for(int j=0;j<150;j++) delay_1ms(1);
        for(int i=0;i<50000;i++) fmq(1);
        fmq(0);
        Set_Pwm(0, 0);
        flag_m=0;
        mode=0;
        state=0;
       }

        }
        

}

void mode4(void)//第四题
{
        if(flag_m==1)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if(!state)  Set_Pwm(600+Position_PID1 (Yaw,-36+3*goround), 540-Position_PID1 (Yaw,-36+3*goround));
        else     
         {
            state=1;
            flag_m=2;
             for(int j=0;j<150;j++) delay_1ms(1);
             for(int i=0;i<50000;i++) fmq(1);
            fmq(0);
           
         }
        }
        
        if(flag_m==2)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if((!state)&&((Yaw<=-150)||(Yaw>=150))) 
       {
        for(int j=0;j<150;j++) delay_1ms(1);
        for(int i=0;i<50000;i++) fmq(1);
        fmq(0);
        flag_m=3;
       }
        }

        if (flag_m==3)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if(!state)  Set_Pwm(600+Position_PID1 (Yaw,-143+2.7*goround), 540-Position_PID1 (Yaw,-143+2.7*goround));
        else     
         {
            state=1;
            flag_m=4;
              for(int j=0;j<150;j++) delay_1ms(1);
            for(int i=0;i<50000;i++) fmq(1);
            fmq(0);
       
         }
        }

        if(flag_m==4)
        {
        if(L1+L2+M0+R1+R2)   state=1;
        else                 state=0;
        state_last=state;
        if((!state)&&(Yaw<30)&&(Yaw>-30)) 
       {
        for(int j=0;j<150;j++) delay_1ms(1);
        for(int i=0;i<50000;i++) fmq(1);
        fmq(0);
        Set_Pwm(0, 0);
        goround++;
        if(goround<=3) flag_m=1;
        else     
        {    
          flag_m=0;
          mode=0;
          state=0;
        }
 
       }

        }
        
}


int main(void)
{
  
    SYSCFG_DL_init();

    IIC_init();
    MPU6050_Init();
    mpu_dmp_init();
    //UART_Init();
    //ADC_Init();
    Motor_Init();
    Timer_Init();
    interrupt_Init();
    PWM_Init();
    OLED_Init();
   // Set_Pwm(500,2000);
    while (1) 
    {
        
        get_key();
        switch (mode)
        {
            case 1:mode1();break;
            case 2:mode2();break;
            case 3:mode3();break;
            case 4:mode4();break;
        }

        OLED_ShowSignedNum(1,7,CountL,6);
        OLED_ShowSignedNum(2,7,CountR,6);
        OLED_ShowSignedNum(3,7,SpeedL,4);
        OLED_ShowSignedNum(4,7,SpeedR,4);
       // mpu_dmp_get_data(&Pitch,&Roll,&Yaw);
        OLED_ShowSignedNum(3,12,Yaw,3);
        OLED_ShowNum(4,13,mode,2);
    }
}
