#include "sys.h"

#include "stdio.h"
#include "string.h"

volatile unsigned int delay_times = 0;
volatile unsigned char uart_data = 0;

void IIC_init(void)
{
    NVIC_EnableIRQ(I2C_MPU6050_INST_INT_IRQN);
}


void delay_us(unsigned long __us) 
{

    delay_cycles(CPUCLK_FREQ/1000000);
}


void delay_ms(unsigned long ms) 
{
	delay_cycles(CPUCLK_FREQ/1000);
}



void delay_1us(unsigned long __us)
{ 
    delay_us(__us); 
}



void delay_1ms(unsigned long ms)
{ 
    delay_ms(ms); 
}


