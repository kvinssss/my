#ifndef __MOTOR_H
#define __MOTOR_H

#include <sys.h>	



#define AIN2(x)   x?DL_GPIO_setPins(motor_PORT, motor_GPIO_motor_a1_PIN):DL_GPIO_clearPins(motor_PORT, motor_GPIO_motor_a1_PIN )
#define AIN1(x)   x?DL_GPIO_setPins(motor_PORT, motor_GPIO_motor_a0_PIN):DL_GPIO_clearPins(motor_PORT, motor_GPIO_motor_a0_PIN )
#define BIN1(x)   x?DL_GPIO_setPins(motor_PORT, motor_GPIO_motor_b0_PIN):DL_GPIO_clearPins(motor_PORT, motor_GPIO_motor_b0_PIN )
#define BIN2(x)   x?DL_GPIO_setPins(motor_PORT, motor_GPIO_motor_b1_PIN):DL_GPIO_clearPins(motor_PORT, motor_GPIO_motor_b1_PIN )
#define PWMA(x)   DL_TimerG_setCaptureCompareValue(PWM_INST, 3199-x, DL_TIMER_CC_0_INDEX)
#define PWMB(x)   DL_TimerG_setCaptureCompareValue(PWM_INST, 3199-x, DL_TIMER_CC_1_INDEX)

void Motor_Init(void);
void Set_Pwm(int moto1,int moto2);
int myabs(int a);
/*void Xianfu_Pwm(void);
void Turn_Off(float angle);*/

#endif
