#ifndef __TIM_H
#define __TIM_H

void Timer_Init(void);
int TIM_Counter(void);

#endif
