#ifndef __USART_H
#define __USART_H

void Uart3_Init(void);
int GET_X(void);
int GET_Y(void);
u8 GET_flag(void);
#endif
